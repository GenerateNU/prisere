// lambda-src/ses-client.ts
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

// emails/email-template.tsx
import { Html, Body, Container, Heading, Text, Section, Hr, Img, Tailwind, render } from "@react-email/components";
import { jsxDEV } from "react/jsx-dev-runtime";
function DisasterEmail({ message }) {
  const declarationDate = new Date(message.declarationDate).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  return /* @__PURE__ */ jsxDEV(Html, {
    children: /* @__PURE__ */ jsxDEV(Tailwind, {
      config: {
        theme: {
          extend: {
            fontFamily: {
              sans: ["PT Sans", "Arial", "sans-serif"]
            }
          }
        }
      },
      children: /* @__PURE__ */ jsxDEV(Body, {
        className: "flex flex-col bg-gray-100 m-0 p-0 font-sans justify-center items-center",
        children: /* @__PURE__ */ jsxDEV(Container, {
          className: "flex flex-col bg-white max-w-xl mx-auto",
          children: [
            /* @__PURE__ */ jsxDEV(Section, {
              className: "bg-white relative px-10 pt-12 min-h-[110px] max-w-xl",
              children: [
                /* @__PURE__ */ jsxDEV("div", {
                  className: "absolute top-0 left-0 w-full h-full overflow-hidden",
                  children: /* @__PURE__ */ jsxDEV("svg", {
                    width: "100%",
                    height: "100%",
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "none",
                    className: "block",
                    children: /* @__PURE__ */ jsxDEV("polygon", {
                      points: "0,0 75,0 65,100 0,100",
                      fill: "#8a1e41"
                    }, undefined, false, undefined, this)
                  }, undefined, false, undefined, this)
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(Heading, {
                  className: "text-white font-semibold text-[clamp(1.25rem,3vw,3rem)] m-0 relative z-10",
                  children: "FEMA Disaster Alert"
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this),
            /* @__PURE__ */ jsxDEV(Section, {
              className: "p-10",
              children: [
                /* @__PURE__ */ jsxDEV(Text, {
                  className: "text-base mb-6",
                  children: [
                    "Hello ",
                    message.firstName,
                    ","
                  ]
                }, undefined, true, undefined, this),
                /* @__PURE__ */ jsxDEV(Text, {
                  className: "text-lg mb-8",
                  children: [
                    "A ",
                    /* @__PURE__ */ jsxDEV("strong", {
                      children: message.declarationType
                    }, undefined, false, undefined, this),
                    " disaster has been declared in your area."
                  ]
                }, undefined, true, undefined, this),
                /* @__PURE__ */ jsxDEV("table", {
                  className: "w-full mb-10",
                  children: /* @__PURE__ */ jsxDEV("tbody", {
                    children: [
                      /* @__PURE__ */ jsxDEV("tr", {
                        children: [
                          /* @__PURE__ */ jsxDEV("td", {
                            className: "text-gray-500 text-sm pb-3",
                            children: "Declaration Date"
                          }, undefined, false, undefined, this),
                          /* @__PURE__ */ jsxDEV("td", {
                            className: "text-gray-700 text-sm pb-3",
                            children: declarationDate
                          }, undefined, false, undefined, this)
                        ]
                      }, undefined, true, undefined, this),
                      /* @__PURE__ */ jsxDEV("tr", {
                        children: [
                          /* @__PURE__ */ jsxDEV("td", {
                            className: "text-gray-500 text-sm pb-3",
                            children: "Incident Type"
                          }, undefined, false, undefined, this),
                          /* @__PURE__ */ jsxDEV("td", {
                            className: "text-gray-700 text-sm pb-3",
                            children: Array.isArray(message.incidentTypeMeanings) ? message.incidentTypeMeanings.join(", ") : message.incidentTypeMeanings
                          }, undefined, false, undefined, this)
                        ]
                      }, undefined, true, undefined, this),
                      /* @__PURE__ */ jsxDEV("tr", {
                        children: [
                          /* @__PURE__ */ jsxDEV("td", {
                            className: "text-gray-500 text-sm pb-3",
                            children: "County"
                          }, undefined, false, undefined, this),
                          /* @__PURE__ */ jsxDEV("td", {
                            className: "text-gray-700 text-sm pb-3",
                            children: message.city ?? "Not specified"
                          }, undefined, false, undefined, this)
                        ]
                      }, undefined, true, undefined, this)
                    ]
                  }, undefined, true, undefined, this)
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(Text, {
                  className: "text-[15px] leading-6 mb-8",
                  children: [
                    "Please review this alert and take necessary precautions. For more information about this disaster and available assistance, visit",
                    " ",
                    /* @__PURE__ */ jsxDEV("a", {
                      href: "https://fema.gov",
                      className: "font-semibold underline text-black",
                      children: "FEMA.gov"
                    }, undefined, false, undefined, this),
                    "."
                  ]
                }, undefined, true, undefined, this),
                /* @__PURE__ */ jsxDEV(Text, {
                  className: "text-base mb-8",
                  children: "Stay safe,"
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(Img, {
                  className: "w-50 h-20",
                  src: "https://prisere.com/wp-content/uploads/2023/09/Prisere-logo-transparent.png"
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(Hr, {
                  className: "border-gray-300 my-8"
                }, undefined, false, undefined, this),
                /* @__PURE__ */ jsxDEV(Text, {
                  className: "text-xs text-gray-500",
                  children: "You received this email because you have registered for disaster alerts in your area."
                }, undefined, false, undefined, this)
              ]
            }, undefined, true, undefined, this)
          ]
        }, undefined, true, undefined, this)
      }, undefined, false, undefined, this)
    }, undefined, false, undefined, this)
  }, undefined, false, undefined, this);
}
async function renderDisasterEmailHTML(message) {
  return render(/* @__PURE__ */ jsxDEV(DisasterEmail, {
    message
  }, undefined, false, undefined, this), { pretty: true });
}
async function renderDisasterEmailText(message) {
  return render(/* @__PURE__ */ jsxDEV(DisasterEmail, {
    message
  }, undefined, false, undefined, this), { plainText: true });
}

// lambda-src/ses-client.ts
class SESEmailService {
  client;
  fromEmail;
  constructor(region = "us-east-1", fromEmail) {
    const config = {
      region: process.env.AWS_REGION || region
    };
    if (false) {}
    this.client = new SESClient(config);
    this.fromEmail = fromEmail;
  }
  async sendDisasterEmail(message) {
    const htmlBody = await renderDisasterEmailHTML(message);
    const textBody = await renderDisasterEmailText(message);
    const destination = {
      ToAddresses: [message.to]
    };
    if (message.alt) {
      destination.BccAddresses = [message.alt];
    }
    const command = new SendEmailCommand({
      Source: this.fromEmail,
      Destination: destination,
      Message: {
        Subject: {
          Data: message.subject,
          Charset: "UTF-8"
        },
        Body: {
          Html: {
            Data: htmlBody,
            Charset: "UTF-8"
          },
          Text: {
            Data: textBody,
            Charset: "UTF-8"
          }
        }
      }
    });
    await this.client.send(command);
  }
}

// lambda-src/index.ts
var sesService = new SESEmailService(process.env.SES_REGION || "us-east-1", process.env.SES_FROM_EMAIL || "priseregenerate@gmail.com");
var handler = async (event) => {
  console.log(`Processing ${event.Records.length} messages`);
  const batchItemFailures = [];
  for (const record of event.Records) {
    try {
      await processRecord(record);
      console.log(`Successfully processed message ${record.messageId}`);
    } catch (error) {
      console.error(`Failed to process message ${record.messageId}:`, error);
      batchItemFailures.push({
        itemIdentifier: record.messageId
      });
    }
  }
  console.log(`Processed ${event.Records.length} messages. Failures: ${batchItemFailures.length}`);
  return {
    batchItemFailures
  };
};
async function processRecord(record) {
  const message = JSON.parse(record.body);
  console.log(`Sending email to ${message.to} for disaster ${message.disasterId}`);
  if (!message.to || !message.firstName || !message.declarationType) {
    throw new Error("Missing required fields in message");
  }
  await sesService.sendDisasterEmail(message);
  console.log(`Email sent successfully to ${message.to}`);
}
export {
  handler
};
